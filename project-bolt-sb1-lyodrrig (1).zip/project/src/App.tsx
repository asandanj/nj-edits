import { useState, useRef } from "react";
import { Upload, Wand2, Download, RotateCcw, Image as ImageIcon } from "lucide-react";

interface FilterEffect {
  name: string;
  filter: string;
}

export default function App() {
  const [image, setImage] = useState<string | null>(null);
  const [prompt, setPrompt] = useState("");
  const [currentFilter, setCurrentFilter] = useState<FilterEffect | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const filterMap: { [key: string]: FilterEffect } = {
    cinematic: { name: "Cinematic", filter: "contrast(1.25) saturate(1.25) brightness(0.95)" },
    "black and white": { name: "Black & White", filter: "grayscale(100%)" },
    b: { name: "Black & White", filter: "grayscale(100%)" },
    monochrome: { name: "Black & White", filter: "grayscale(100%)" },
    vintage: { name: "Vintage", filter: "sepia(0.4) contrast(1.1)" },
    retro: { name: "Vintage", filter: "sepia(0.4) contrast(1.1)" },
    bright: { name: "Bright", filter: "brightness(1.25) saturate(1.1)" },
    vivid: { name: "Bright", filter: "brightness(1.25) saturate(1.1)" },
    dark: { name: "Dark", filter: "brightness(0.75) contrast(1.25) saturate(0.9)" },
    moody: { name: "Dark", filter: "brightness(0.75) contrast(1.25) saturate(0.9)" },
    warm: { name: "Warm", filter: "sepia(0.15) saturate(1.1)" },
    cool: { name: "Cool", filter: "hue-rotate(180deg) saturate(0.9)" },
    cold: { name: "Cool", filter: "hue-rotate(180deg) saturate(0.9)" },
    blur: { name: "Blur", filter: "blur(4px)" },
    sharp: { name: "Sharp", filter: "contrast(1.25) saturate(1.1) brightness(1.05)" },
    fade: { name: "Fade", filter: "opacity(0.7) contrast(0.9)" },
  };

  const handleImageUpload = (file: File) => {
    if (file && file.type.startsWith("image/")) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setImage(e.target?.result as string);
        setCurrentFilter(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleImageUpload(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) handleImageUpload(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const applyPrompt = () => {
    const text = prompt.toLowerCase();
    let appliedFilter: FilterEffect | null = null;

    for (const [key, filter] of Object.entries(filterMap)) {
      if (text.includes(key)) {
        appliedFilter = filter;
        break;
      }
    }

    if (appliedFilter) {
      setCurrentFilter(appliedFilter);
    } else {
      setCurrentFilter(null);
    }
  };

  const resetImage = () => {
    setCurrentFilter(null);
    setPrompt("");
  };

  const downloadImage = () => {
    if (!image || !canvasRef.current) return;

    const img = new Image();
    img.onload = () => {
      const canvas = canvasRef.current!;
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext("2d")!;

      if (currentFilter) {
        ctx.filter = currentFilter.filter;
      }
      ctx.drawImage(img, 0, 0);

      canvas.toBlob((blob) => {
        if (blob) {
          const url = URL.createObjectURL(blob);
          const a = document.createElement("a");
          a.href = url;
          a.download = `nj-edits-${Date.now()}.png`;
          a.click();
          URL.revokeObjectURL(url);
        }
      });
    };
    img.src = image;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white">
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-2">
            <ImageIcon className="w-8 h-8 text-blue-400" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              NJ Edits
            </h1>
          </div>
          <p className="text-gray-400 text-lg">
            Edit your photos using prompts. Owned & created by you.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-6">
            {!image ? (
              <div
                onDrop={handleDrop}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onClick={() => fileInputRef.current?.click()}
                className={`border-2 border-dashed rounded-xl p-12 text-center cursor-pointer transition-all ${
                  isDragging
                    ? "border-blue-400 bg-blue-400/10"
                    : "border-gray-600 hover:border-gray-500 hover:bg-gray-800/50"
                }`}
              >
                <Upload className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                <p className="text-xl font-medium mb-2">Drop your image here</p>
                <p className="text-gray-400 text-sm">or click to browse</p>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileChange}
                  className="hidden"
                />
              </div>
            ) : (
              <div className="relative rounded-xl overflow-hidden bg-gray-800 shadow-2xl">
                <img
                  src={image}
                  alt="Original"
                  className="w-full h-auto"
                />
                <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-medium">
                  Original
                </div>
              </div>
            )}

            <div className="bg-gray-800 rounded-xl p-6 space-y-4 shadow-xl">
              <div>
                <label className="block text-sm font-medium mb-2 text-gray-300">
                  Describe your edit
                </label>
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      applyPrompt();
                    }
                  }}
                  placeholder="Try: cinematic, black and white, vintage, bright, dark, warm, cool..."
                  className="w-full bg-gray-900 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                  rows={3}
                />
              </div>

              <button
                onClick={applyPrompt}
                disabled={!image || !prompt}
                className="w-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 disabled:from-gray-700 disabled:to-gray-700 disabled:cursor-not-allowed text-white font-medium py-3 px-4 rounded-lg transition-all flex items-center justify-center gap-2 shadow-lg hover:shadow-xl"
              >
                <Wand2 className="w-5 h-5" />
                Apply Edit
              </button>

              {image && (
                <div className="flex gap-3">
                  <button
                    onClick={resetImage}
                    className="flex-1 bg-gray-700 hover:bg-gray-600 text-white font-medium py-2 px-4 rounded-lg transition-all flex items-center justify-center gap-2"
                  >
                    <RotateCcw className="w-4 h-4" />
                    Reset
                  </button>
                  <button
                    onClick={downloadImage}
                    disabled={!currentFilter}
                    className="flex-1 bg-green-600 hover:bg-green-700 disabled:bg-gray-700 disabled:cursor-not-allowed text-white font-medium py-2 px-4 rounded-lg transition-all flex items-center justify-center gap-2"
                  >
                    <Download className="w-4 h-4" />
                    Download
                  </button>
                </div>
              )}
            </div>
          </div>

          <div>
            {image ? (
              <div className="relative rounded-xl overflow-hidden bg-gray-800 shadow-2xl">
                <img
                  src={image}
                  alt="Edited"
                  style={{
                    filter: currentFilter?.filter || "none",
                  }}
                  className="w-full h-auto transition-all duration-500"
                />
                <div className="absolute top-4 left-4 bg-blue-500/80 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-medium">
                  {currentFilter ? currentFilter.name : "Preview"}
                </div>
              </div>
            ) : (
              <div className="border-2 border-dashed border-gray-700 rounded-xl p-12 text-center h-full flex items-center justify-center">
                <div>
                  <ImageIcon className="w-16 h-16 mx-auto mb-4 text-gray-600" />
                  <p className="text-gray-500 text-lg">Preview will appear here</p>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="mt-8 bg-gray-800/50 rounded-xl p-6 border border-gray-700">
          <h2 className="text-lg font-semibold mb-3 text-gray-300">Quick Tips</h2>
          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-3 text-sm">
            <div className="bg-gray-900/50 rounded-lg p-3">
              <span className="text-blue-400 font-medium">cinematic</span>
              <p className="text-gray-400 text-xs mt-1">High contrast movie look</p>
            </div>
            <div className="bg-gray-900/50 rounded-lg p-3">
              <span className="text-blue-400 font-medium">vintage</span>
              <p className="text-gray-400 text-xs mt-1">Retro sepia tone</p>
            </div>
            <div className="bg-gray-900/50 rounded-lg p-3">
              <span className="text-blue-400 font-medium">black and white</span>
              <p className="text-gray-400 text-xs mt-1">Classic monochrome</p>
            </div>
            <div className="bg-gray-900/50 rounded-lg p-3">
              <span className="text-blue-400 font-medium">warm</span>
              <p className="text-gray-400 text-xs mt-1">Cozy warm tones</p>
            </div>
            <div className="bg-gray-900/50 rounded-lg p-3">
              <span className="text-blue-400 font-medium">dark</span>
              <p className="text-gray-400 text-xs mt-1">Moody atmosphere</p>
            </div>
            <div className="bg-gray-900/50 rounded-lg p-3">
              <span className="text-blue-400 font-medium">bright</span>
              <p className="text-gray-400 text-xs mt-1">Enhanced brightness</p>
            </div>
          </div>
        </div>

        <canvas ref={canvasRef} className="hidden" />

        <footer className="mt-12 pt-8 border-t border-gray-700 text-center text-gray-500 text-sm">
          © 2025 NJ Edits — All rights reserved
        </footer>
      </div>
    </div>
  );
}
